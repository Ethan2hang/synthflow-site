#!/usr/bin/env python3
"""Serve the bundled SynthFlow frontend using only Python's standard library."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
import webbrowser


def main():
    parser = argparse.ArgumentParser(description="Start the SynthFlow frontend preview")
    parser.add_argument("--port", type=int, default=5178)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    directory = Path(__file__).resolve().parent / "web"
    if not (directory / "index.html").is_file():
        parser.exit(1, "Missing web/index.html. Extract the complete ZIP first.\n")
    handler = partial(SimpleHTTPRequestHandler, directory=str(directory))
    try:
        server = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    except OSError as error:
        parser.exit(1, f"Could not start server: {error}\nTry: python3 start.py --port 5180\n")
    url = f"http://127.0.0.1:{server.server_port}/"
    print(f"SynthFlow frontend preview: {url}", flush=True)
    print("Keep this terminal open. Press Ctrl+C to stop.", flush=True)
    print("Sound generation requires a separately running backend.", flush=True)
    if not args.no_browser:
        try:
            webbrowser.open(url)
        except webbrowser.Error:
            print("Open the URL above in your browser.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nPreview stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
