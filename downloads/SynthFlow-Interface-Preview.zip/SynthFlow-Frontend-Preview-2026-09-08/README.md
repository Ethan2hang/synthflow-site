# SynthFlow 前端体验包 · 2026-09-08

## 快速启动

先完整解压 ZIP。需要 Python 3.8 或更新版本，不需要 Node.js、npm 或安装 Python 依赖。

- macOS：双击 `Start-Mac.command`。
- Windows：双击 `Start-Windows.bat`。
- Linux，或双击无法启动：在解压目录打开终端，运行 `python3 start.py`。
- Windows 的终端命令为 `py -3 start.py`。

脚本会打开浏览器，默认地址为 http://127.0.0.1:5178/。
保持终端开启，按 Ctrl+C 停止。若浏览器没有自动打开，请手动打开上面的地址。
如果端口被占用，运行 `python3 start.py --port 5180`（Windows 使用 `py -3`）。
没有 Python 时，请从 https://www.python.org/downloads/ 安装 Python 3。
请通过启动脚本访问页面，不要直接双击 `web/index.html`。

## 后端连接

这是前端体验包，不包含后端、模型权重、音频素材或 VST 插件。
不连接后端也能检查输入框、模型菜单、主题和布局；生成声音、上传处理和项目数据需要可用后端。
页面提示后端不可达，在尚未启动后端时属于正常情况。

默认后端地址为 `http://localhost:8000`，指运行此包的同事自己的电脑。
如果同事已有 SynthFlow 后端，在前端左上角 Account → Advanced → Backend URL
填入该后端地址并 Save。连接其他电脑的后端时，地址要使用那台电脑可访问的主机名或 IP；
后端需允许此预览页面来源的 CORS 请求。

浏览器体验不等于 JUCE/VST/DAW 原生宿主验证。

## 本次体验重点

- 提示词独占上排，可输入多行。
- Audio 附件入口在左下，模型选择和发送按钮在右下。
- 模型菜单向上展开，采用圆角、柔和阴影与勾选状态。
- 模型菜单支持方向键、Home/End、Enter/Space、Esc，以及点击外部关闭。
- 可在 Account → Appearance 切换 Light / Dark / System。

## 版本与验证

Vue 3 + Vite 的生产构建，已包含 Vue 运行时，无需联网下载前端依赖。
基于 `codex/vue-migration-m0` 分支的 `f142b760557357484d9909942418797aa6272a3c`，
包含本次已确认但尚未提交的 Composer.vue、styles.css 与 composer.test.js 改动。
784 项前端测试通过，三文件生产构建审计通过。
已检查菜单选择、键盘交互及 1024px 窗口布局；未验证连接真实后端生成声音。

`BUILD-INFO.json` 记录精确源码文件与页面构建文件的 SHA-256。
`SHA256SUMS.txt` 可用于核对包内文件完整性。
